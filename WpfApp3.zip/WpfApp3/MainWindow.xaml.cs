﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Dashboard button click handler
        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            // Example logic for opening the dashboard (if any)
            MessageBox.Show("Dashboard clicked!");
        }

        // Submit Claim button click handler
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            SubmitClaim submitClaimWindow = new SubmitClaim();
            submitClaimWindow.Show();
        }

        // View Claim button click handler
        private void ViewClaims_Click(object sender, RoutedEventArgs e)
        {
            ViewClaims viewClaimsWindow = new ViewClaims();
            viewClaimsWindow.Show();
           
        }

        // Approve Claims button click handler
        private void ApproveClaims_Click(object sender, RoutedEventArgs e)
        {
            // Logic for handling claim approvals (for now just a message box)
            MessageBox.Show("Approve Claims clicked!");
        }

        // Reports button click handler
        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            // Logic to handle reports (for now just a message box)
            MessageBox.Show("Reports clicked!");
        }
    }

}
