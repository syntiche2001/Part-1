﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{
    public partial class ClaimSubmissionForm : Window
    {
        public ClaimSubmissionForm()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Parse hours and rate, and display the calculated amount or handle data submission.
                if (int.TryParse(txtHoursWorked.Text, out int hoursWorked) &&
                    double.TryParse(txtHourlyRate.Text, out double hourlyRate))
                {
                    string notes = txtNotes.Text;

                    // Process the claim here (e.g., save to database or process further).
                    MessageBox.Show($"Claim submitted:\nHours: {hoursWorked}\nRate: {hourlyRate}\nNotes: {notes}");
                }
                else
                {
                    MessageBox.Show("Please enter valid numbers for Hours Worked and Hourly Rate.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            // Use file dialog to select and display uploaded file name
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Document files (*.pdf;*.docx;*.xlsx)|*.pdf;*.docx;*.xlsx"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                txtUploadedFile.Text = openFileDialog.FileName;
                MessageBox.Show("File uploaded successfully.");
            }
        }
    }
}
