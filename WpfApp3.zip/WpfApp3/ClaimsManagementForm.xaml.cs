﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


    namespace WpfApp3
    {
        public partial class ClaimsManagementForm : Window
        {
            public ClaimsManagementForm()
            {
                InitializeComponent();
                LoadClaimsData();
            }

            private void LoadClaimsData()
            {
                // Example data source
                dgClaims.ItemsSource = new[]
                {
                new Claim { HoursWorked = 10, HourlyRate = 50, Notes = "Sample Claim 1" },
                new Claim { HoursWorked = 15, HourlyRate = 45, Notes = "Sample Claim 2" }
            };
            }

            private void Approve_Click(object sender, RoutedEventArgs e)
            {
                // Handle approve button click
                var button = sender as Button;
                var claim = (Claim)button?.DataContext;

                if (claim != null)
                {
                    MessageBox.Show($"Claim approved for: {claim.Notes}");
                }
            }

            private void Reject_Click(object sender, RoutedEventArgs e)
            {
                // Handle reject button click
                var button = sender as Button;
                var claim = (Claim)button?.DataContext;

                if (claim != null)
                {
                    MessageBox.Show($"Claim rejected for: {claim.Notes}");
                }
            }
        }

        // Define your Claim data model here or separately
        public class Claim
        {
            public int HoursWorked { get; set; }
            public double HourlyRate { get; set; }
            public string Notes { get; set; }
        }
    }


