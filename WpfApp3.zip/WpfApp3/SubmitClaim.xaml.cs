﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration; 



namespace WpfApp3
{
    public partial class SubmitClaim : Window
    {
        public SubmitClaim()
        {
            InitializeComponent();
        }

        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                UploadedFileTextBlock.Text = openFileDialog.FileName;
            }
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var lecturerName = LecturerNameTextBox.Text;
                var hoursWorked = int.Parse(HoursWorkedTextBox.Text);
                var hourlyRate = decimal.Parse(HourlyRateTextBox.Text);
                var additionalNotes = AdditionalNotesTextBox.Text;
                var uploadedFile = UploadedFileTextBlock.Text;

                // Call the method to insert the data into the database
                InsertClaimIntoDatabase(lecturerName, hoursWorked, hourlyRate, additionalNotes, uploadedFile);

                MessageBox.Show("Claim submitted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InsertClaimIntoDatabase(string lecturerName, int hoursWorked, decimal hourlyRate, string additionalNotes, string uploadedFile)
        {
            // Define the connection string (could be retrieved from App.config)
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ClaimsDatabase"].ConnectionString;

            // Create the SQL query
            string query = "INSERT INTO Claims (LecturerName, HoursWorked, HourlyRate, AdditionalNotes, UploadedFile) " +
                           "VALUES (@LecturerName, @HoursWorked, @HourlyRate, @AdditionalNotes, @UploadedFile)";

            // Create a SQL connection and command
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to prevent SQL injection
                    command.Parameters.AddWithValue("@LecturerName", lecturerName);
                    command.Parameters.AddWithValue("@HoursWorked", hoursWorked);
                    command.Parameters.AddWithValue("@HourlyRate", hourlyRate);
                    command.Parameters.AddWithValue("@AdditionalNotes", additionalNotes);
                    command.Parameters.AddWithValue("@UploadedFile", uploadedFile);

                    // Open the connection and execute the query
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

       

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigation logic
        }
    }
}