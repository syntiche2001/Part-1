﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for ViewClaims.xaml
    /// </summary>
    public partial class ViewClaims : Window
    {
        public ViewClaims()
        {
            InitializeComponent();
            LoadClaims();
        }

        // Sample Claim class for binding
        public class Claim
        {
            public int ClaimId { get; set; }
            public string LecturerName { get; set; }
            public int HoursWorked { get; set; }
            public double HourlyRate { get; set; }
            public double TotalAmount => HoursWorked * HourlyRate; // Auto-calculate
            public string Notes { get; set; }
        }

        // Sample data loader
        private void LoadClaims()
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim { ClaimId = 1, LecturerName = "John Doe", HoursWorked = 10, HourlyRate = 50, Notes = "Extra hours" },
                new Claim { ClaimId = 2, LecturerName = "Jane Smith", HoursWorked = 15, HourlyRate = 60, Notes = "Overtime" }
            };

            dgClaims.ItemsSource = claims;
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (dgClaims.SelectedItem is Claim claim)
            {
                MessageBox.Show($"Claim ID {claim.ClaimId} approved.");
                // Code to update the claim status
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (dgClaims.SelectedItem is Claim claim)
            {
                MessageBox.Show($"Claim ID {claim.ClaimId} rejected.");
                // Code to update the claim status
            }
        }
    }
}
